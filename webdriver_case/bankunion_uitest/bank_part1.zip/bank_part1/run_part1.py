#encoding=utf-8
'''
Created on 2016年5月21日

@author: Administrator
'''

import unittest
import time
from HTMLTestRunner import HTMLTestRunner
#加载测试文件

from bank_part1.test_index_availability import Index_avaliability_Test
from bank_part1.test_help_availability import test_help_availability
from bank_part1.test_bidlist_availability import test_bidlist_availability
from bank_part1.test_passport_availability import test_passport_availability
from bank_part1.test_my import my_account


#构建测试集
suite = unittest.TestSuite()

suite.addTest(Index_avaliability_Test("test_all_href"))
suite.addTest(Index_avaliability_Test("test_all_css"))
suite.addTest(Index_avaliability_Test("test_all_img"))
suite.addTest(Index_avaliability_Test("test_all_js"))

suite.addTest(test_help_availability("test_all_href"))
suite.addTest(test_help_availability("test_all_css"))
suite.addTest(test_help_availability("test_all_img"))
suite.addTest(test_help_availability("test_all_js"))

suite.addTest(test_bidlist_availability("test_all_href"))
suite.addTest(test_bidlist_availability("test_all_css"))
suite.addTest(test_bidlist_availability("test_all_img"))
suite.addTest(test_bidlist_availability("test_all_js"))
  
suite.addTest(test_passport_availability("test_all_href"))
suite.addTest(test_passport_availability("test_all_css"))
suite.addTest(test_passport_availability("test_all_img"))
suite.addTest(test_passport_availability("test_all_js"))

suite.addTest(my_account("test_my_safe"))
suite.addTest(my_account("test_my"))

#执行测试
if __name__=='__main__':  
    #按照一定格式获取当前时间
    now = time.strftime("%Y-%m-%d %H-%M-%S")
    
    #定义报告存放路径
    filename = 'C:\\' + now +'result.html'
    fp = file(filename,'wb')
    
    #定义测试报告
    runner = HTMLTestRunner(
                            stream=fp,
                            title=u'首页非200测试',
                            description=u'用例执行情况:'
                            )
    
    runner.run(suite)   
    fp.close()
      
#    unittest.main()   







