#encoding=utf-8
'''
Created on 2016年5月21日

@author: Administrator
'''

import HTMLParser
#from conf import bankconf

class MyParser(HTMLParser.HTMLParser):  
    def __init__(self):  
        HTMLParser.HTMLParser.__init__(self) 
        self.links = []
        self.css = []
        self.img = []
        self.js = []
                         
    def handle_starttag(self, tag, attrs):  
        # 这里重新定义了处理开始标签的函数  
        if tag == 'a':  
            # 判断标签<a>的属性  
            for name,value in attrs:  
                if name == 'href'  :  
#   print value  
                    if value.startswith('http'):
                        self.links.append(value)
                    elif value.startswith('/'):
                        self.links.append('http://rej.jzbank.com'+value)
                    else:
                        print(value)   
        elif tag == 'link' :
            for name,value in attrs:  
                if name == 'href'  :  
                    self.css.append(value) 
        elif tag == 'img':
            for name,value in attrs:
                if name == 'src'   :
                    if value.startswith('http'):
                        self.img.append(value)
                    elif value.startswith('/'):
                        self.img.append('http://rej.jzbank.com'+value)
        elif tag == 'script':
            for name,value in attrs:
                if name == 'src':
                    self.js.append(value)                    




